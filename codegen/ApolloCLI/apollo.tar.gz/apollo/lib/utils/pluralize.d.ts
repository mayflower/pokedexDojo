export declare function pluralize(quantity: string | number | null, singular: string, plural?: string): string;
//# sourceMappingURL=pluralize.d.ts.map